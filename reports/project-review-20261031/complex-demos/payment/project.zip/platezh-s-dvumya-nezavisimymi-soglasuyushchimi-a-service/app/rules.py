"""Правила переходов модели: условие (guard) и одновременное присваивание (effects).

Функции effects_* читают только состояние до события `s` и возвращают новые значения
присваиваемых переменных; остальные переменные не меняются. Правила меняются только через
новую согласованную версию модели и повторную генерацию."""
# Версия v_c5121f0e8fea4432aad69c10fff47607, spec_hash 3c63553df8f7f5b8c7f0c9798e4e3d4bbb4c045f0f33850141ed0be9e0458f42, proveryalka-codegen 1.0.0
from dataclasses import dataclass
from typing import Callable


@dataclass(frozen=True)
class Transition:
    id: str
    name: str
    requirement_ids: tuple
    assigns: tuple
    guard: Callable
    effects: Callable


# Переход submit_for_review «Подать на согласование»
# req_48e457bf3dbd570bb264a37b73c35990: Действие «Подать на согласование» переводит поручение из Draft в Review.; req_85e0cfb054105e959c4b9775aafa50b7: Из Paid и Cancelled действий нет.; req_d95075df515d53209c12aefda8319544: Неизменяемые пер…
def guard_submit_for_review(s):
    return s['status'] == 'Draft'


def effects_submit_for_review(s):
    return {
        'status': 'Review',
    }


# Переход approve_a «А даёт согласие»
# req_d94ac30dc50c5cfeb67c9c2dddde3f83: У платежа два независимых согласующих: А и Б.; req_793f2f80d2915efa9132baa76b4fb659: В Review каждый согласующий может отдельно поставить свою отметку согласия, если она ещё не стоит.; req_85e0cfb05410…
def guard_approve_a(s):
    return (s['status'] == 'Review') and (not s['approved_a'])


def effects_approve_a(s):
    return {
        'approved_a': True,
    }


# Переход approve_b «Б даёт согласие»
# req_d94ac30dc50c5cfeb67c9c2dddde3f83: У платежа два независимых согласующих: А и Б.; req_793f2f80d2915efa9132baa76b4fb659: В Review каждый согласующий может отдельно поставить свою отметку согласия, если она ещё не стоит.; req_85e0cfb05410…
def guard_approve_b(s):
    return (s['status'] == 'Review') and (not s['approved_b'])


def effects_approve_b(s):
    return {
        'approved_b': True,
    }


# Переход complete_review «Завершить согласование»
# req_db5f379b58755e6b8a7ba3e22f315826: Отдельное действие «Завершить согласование» переводит поручение из Review в Approved только при наличии обеих отметок.; req_85e0cfb054105e959c4b9775aafa50b7: Из Paid и Cancelled действий нет.; req_d950…
def guard_complete_review(s):
    return (s['status'] == 'Review') and (s['approved_a'] and s['approved_b'])


def effects_complete_review(s):
    return {
        'status': 'Approved',
    }


# Переход revoke_a «А отзывает согласие»
# req_d94ac30dc50c5cfeb67c9c2dddde3f83: У платежа два независимых согласующих: А и Б.; req_f733dfb689045f05a53fcc41164e258e: Каждый согласующий может отозвать свою отметку в Review или Approved.; req_06acdd527d9158408233550bd32d8985: Отзыв с…
def guard_revoke_a(s):
    return (s['status'] == 'Review') or (s['status'] == 'Approved')


def effects_revoke_a(s):
    return {
        'approved_a': False,
        'status': 'Review',
    }


# Переход revoke_b «Б отзывает согласие»
# req_d94ac30dc50c5cfeb67c9c2dddde3f83: У платежа два независимых согласующих: А и Б.; req_f733dfb689045f05a53fcc41164e258e: Каждый согласующий может отозвать свою отметку в Review или Approved.; req_06acdd527d9158408233550bd32d8985: Отзыв с…
def guard_revoke_b(s):
    return (s['status'] == 'Review') or (s['status'] == 'Approved')


def effects_revoke_b(s):
    return {
        'approved_b': False,
        'status': 'Review',
    }


# Переход pay «Оплатить»
# req_bf2da64ede4c56a2b9ce8dfb7110b8e8: Действие «Оплатить» разрешено только в Approved при отсутствии отмены; оно устанавливает этап Paid и executed=true.; req_9e63696a936b5f52a85f4221aa19c03a: Условие оплаты не перепроверяет отдельные отме…
def guard_pay(s):
    return (s['status'] == 'Approved') and (not s['cancelled'])


def effects_pay(s):
    return {
        'status': 'Paid',
        'executed': True,
    }


# Переход cancel «Отменить»
# req_979d1f8e4bc851b18f789209c88ca98b: Действие «Отменить» доступно в Draft, Review или Approved, если исполнение ещё не произошло; оно устанавливает cancelled=true и этап Cancelled.; req_85e0cfb054105e959c4b9775aafa50b7: Из Paid и Cancelle…
def guard_cancel(s):
    return ((s['status'] == 'Draft') or ((s['status'] == 'Review') or (s['status'] == 'Approved'))) and (not s['executed'])


def effects_cancel(s):
    return {
        'cancelled': True,
        'status': 'Cancelled',
    }


TRANSITIONS = {
    'submit_for_review': Transition(
        id='submit_for_review',
        name='Подать на согласование',
        requirement_ids=('req_48e457bf3dbd570bb264a37b73c35990', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('status',),
        guard=guard_submit_for_review,
        effects=effects_submit_for_review,
    ),
    'approve_a': Transition(
        id='approve_a',
        name='А даёт согласие',
        requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('approved_a',),
        guard=guard_approve_a,
        effects=effects_approve_a,
    ),
    'approve_b': Transition(
        id='approve_b',
        name='Б даёт согласие',
        requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('approved_b',),
        guard=guard_approve_b,
        effects=effects_approve_b,
    ),
    'complete_review': Transition(
        id='complete_review',
        name='Завершить согласование',
        requirement_ids=('req_db5f379b58755e6b8a7ba3e22f315826', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('status',),
        guard=guard_complete_review,
        effects=effects_complete_review,
    ),
    'revoke_a': Transition(
        id='revoke_a',
        name='А отзывает согласие',
        requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('approved_a', 'status'),
        guard=guard_revoke_a,
        effects=effects_revoke_a,
    ),
    'revoke_b': Transition(
        id='revoke_b',
        name='Б отзывает согласие',
        requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('approved_b', 'status'),
        guard=guard_revoke_b,
        effects=effects_revoke_b,
    ),
    'pay': Transition(
        id='pay',
        name='Оплатить',
        requirement_ids=('req_bf2da64ede4c56a2b9ce8dfb7110b8e8', 'req_9e63696a936b5f52a85f4221aa19c03a', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('status', 'executed'),
        guard=guard_pay,
        effects=effects_pay,
    ),
    'cancel': Transition(
        id='cancel',
        name='Отменить',
        requirement_ids=('req_979d1f8e4bc851b18f789209c88ca98b', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'),
        assigns=('cancelled', 'status'),
        guard=guard_cancel,
        effects=effects_cancel,
    ),
}
