"""HTTP API сервиса: модель, текущее состояние и применение событий.

Состояние хранится в памяти одного процесса; события применяются по одному под блокировкой.
"""
from threading import Lock
from typing import Optional, Union

from fastapi import FastAPI
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, StrictBool, StrictInt, StrictStr

from . import engine
from .domain import InvalidState
from .rules import TRANSITIONS
from .spec import GENERATOR, MODEL_NAME, REQUIREMENTS, SPEC_HASH, VARIABLES, VERSION_ID


Value = Union[StrictBool, StrictInt, StrictStr]
REJECTIONS = (InvalidState, engine.UnknownTransition, engine.TransitionNotEnabled, engine.EffectOutOfDomain)


class Body(BaseModel):
    model_config = ConfigDict(extra="forbid")


class EventRequest(Body):
    transition: StrictStr
    expected_revision: Optional[StrictInt] = None


class EvaluateRequest(Body):
    state: dict[str, Value]
    transition: StrictStr


def error(status, code, message):
    return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})


def rejection(transition_id, failure):
    if isinstance(failure, engine.UnknownTransition):
        return error(404, "UNKNOWN_TRANSITION", f"Перехода {transition_id!r} нет в модели")
    if isinstance(failure, engine.TransitionNotEnabled):
        return error(409, "TRANSITION_NOT_ENABLED", f"Условие перехода {transition_id} не выполнено")
    if isinstance(failure, engine.EffectOutOfDomain):
        return error(409, "EFFECT_OUT_OF_DOMAIN", str(failure))
    return error(422, "INVALID_STATE", str(failure))


def describe(variable):
    domain = {"kind": variable.kind}
    if variable.kind == "integer":
        domain.update(minimum=variable.minimum, maximum=variable.maximum)
    if variable.kind == "enum":
        domain["values"] = list(variable.values)
    return {"id": variable.id, "name": variable.name, "domain": domain,
            "initial_value": variable.initial, "requirement_ids": list(variable.requirement_ids)}


def create_app():
    app = FastAPI(title=MODEL_NAME, version=VERSION_ID)
    lock = Lock()
    current = {"state": engine.initial_state(), "revision": 0}

    def snapshot():
        return {"state": dict(current["state"]), "revision": current["revision"],
                "enabled": engine.enabled_transitions(current["state"])}

    @app.get("/model")
    def model():
        return {
            "name": MODEL_NAME, "version_id": VERSION_ID, "spec_hash": SPEC_HASH, "generator": GENERATOR,
            "variables": [describe(variable) for variable in VARIABLES],
            "transitions": [{"id": rule.id, "name": rule.name, "requirement_ids": list(rule.requirement_ids),
                             "assigns": list(rule.assigns)} for rule in TRANSITIONS.values()],
            "requirements": REQUIREMENTS,
        }

    @app.get("/state")
    def state():
        with lock:
            return snapshot()

    @app.post("/events")
    def apply_event(body: EventRequest):
        with lock:
            if body.expected_revision is not None and body.expected_revision != current["revision"]:
                return error(409, "REVISION_CONFLICT", "Состояние изменилось; перечитайте /state")
            try:
                following = engine.apply(current["state"], body.transition)
            except REJECTIONS as failure:
                return rejection(body.transition, failure)
            current["state"] = following
            current["revision"] += 1
            return {**snapshot(), "applied": body.transition}

    @app.post("/evaluate")
    def evaluate(body: EvaluateRequest):
        try:
            following = engine.apply(body.state, body.transition)
        except REJECTIONS as failure:
            return rejection(body.transition, failure)
        return {"state": following, "enabled": engine.enabled_transitions(following)}

    @app.post("/reset")
    def reset():
        with lock:
            current["state"] = engine.initial_state()
            current["revision"] += 1
            return snapshot()

    return app


app = create_app()
