"""Применение события модели к состоянию.

Порядок: проверка состояния, условие перехода, одновременное присваивание (все правые части
вычисляются по состоянию до события), проверка областей нового состояния. Переменные без
присваивания сохраняют значение. Отказ не меняет переданное состояние.
"""
from .domain import InvalidState, validate_state
from .rules import TRANSITIONS
from .spec import INITIAL_STATE, VARIABLES


class UnknownTransition(LookupError):
    """Перехода нет в модели."""


class TransitionNotEnabled(ValueError):
    """Условие перехода ложно в этом состоянии."""


class EffectOutOfDomain(ValueError):
    """Присваивание выводит переменную за область значений."""

    def __init__(self, transition_id, error):
        super().__init__(f"{transition_id}: {error}")
        self.transition_id = transition_id
        self.variable = error.variable


def initial_state():
    return dict(INITIAL_STATE)


def check_state(state):
    return validate_state(VARIABLES, state)


def transition(transition_id):
    try:
        return TRANSITIONS[transition_id]
    except (KeyError, TypeError):
        raise UnknownTransition(transition_id) from None


def enabled_transitions(state):
    current = check_state(state)
    return [rule.id for rule in TRANSITIONS.values() if rule.guard(current)]


def apply(state, transition_id):
    current = check_state(state)
    rule = transition(transition_id)
    if not rule.guard(current):
        raise TransitionNotEnabled(transition_id)
    following = {**current, **rule.effects(current)}
    try:
        return check_state(following)
    except InvalidState as error:
        raise EffectOutOfDomain(transition_id, error) from error
