"""Generated service package."""
