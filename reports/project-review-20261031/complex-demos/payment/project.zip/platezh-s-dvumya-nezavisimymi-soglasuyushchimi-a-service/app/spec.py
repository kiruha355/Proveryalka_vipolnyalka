"""Данные согласованной модели: требования, переменные, области значений, начальное состояние."""
from .domain import Variable


# Модель: Платёж с двумя независимыми согласующими А и Б
MODEL_NAME = 'Платёж с двумя независимыми согласующими А и Б'
VERSION_ID = 'v_c5121f0e8fea4432aad69c10fff47607'
SPEC_HASH = '3c63553df8f7f5b8c7f0c9798e4e3d4bbb4c045f0f33850141ed0be9e0458f42'
GENERATOR = 'proveryalka-codegen 1.0.0'

REQUIREMENTS = {
    'req_d94ac30dc50c5cfeb67c9c2dddde3f83': 'У платежа два независимых согласующих: А и Б.',
    'req_91faa8ff7d5153d4b36fa5764a2a9804': 'Поручение имеет этап Draft, Review, Approved, Paid либо Cancelled.',
    'req_48e457bf3dbd570bb264a37b73c35990': 'Действие «Подать на согласование» переводит поручение из Draft в Review.',
    'req_793f2f80d2915efa9132baa76b4fb659': 'В Review каждый согласующий может отдельно поставить свою отметку согласия, если она ещё не стоит.',
    'req_db5f379b58755e6b8a7ba3e22f315826': 'Отдельное действие «Завершить согласование» переводит поручение из Review в Approved только при наличии обеих отметок.',
    'req_f733dfb689045f05a53fcc41164e258e': 'Каждый согласующий может отозвать свою отметку в Review или Approved.',
    'req_06acdd527d9158408233550bd32d8985': 'Отзыв согласия любым из двух согласующих в Review или Approved одновременно снимает только его собственную отметку и устанавливает status=Review; остальные отметки и флаги сохраняются.',
    'req_bf2da64ede4c56a2b9ce8dfb7110b8e8': 'Действие «Оплатить» разрешено только в Approved при отсутствии отмены; оно устанавливает этап Paid и executed=true.',
    'req_9e63696a936b5f52a85f4221aa19c03a': 'Условие оплаты не перепроверяет отдельные отметки согласующих и доверяет этапу Approved.',
    'req_979d1f8e4bc851b18f789209c88ca98b': 'Действие «Отменить» доступно в Draft, Review или Approved, если исполнение ещё не произошло; оно устанавливает cancelled=true и этап Cancelled.',
    'req_85e0cfb054105e959c4b9775aafa50b7': 'Из Paid и Cancelled действий нет.',
    'req_43ee6409a1065372a3dbf1b686ed9caa': 'После исполнения должны оставаться оба согласия.',
    'req_3fe7ae86fd8f554686b1bc436718900c': 'Отменённый платёж не может быть исполнен.',
    'req_a6f0a511318e52ec9af24859ba5165e4': 'Оплата должна быть достижима.',
    'req_9120945853e5590e8e776b1c1400a279': 'Изначально status=Draft.',
    'req_cee412ddc59a54e5aeb473ceff07d5af': 'Изначально approved_a=false.',
    'req_c2e121b42fdd5aa38eff1086935be325': 'Изначально approved_b=false.',
    'req_67ebe9432bfa533d819b177bdb7fb39e': 'Изначально cancelled=false.',
    'req_53587e990088571daef21a92363096b6': 'Изначально executed=false.',
    'req_d95075df515d53209c12aefda8319544': 'Неизменяемые переменные при каждом действии сохраняют прежние значения.',
}

VARIABLES = (
    # status «Этап поручения» — req_91faa8ff7d5153d4b36fa5764a2a9804, req_48e457bf3dbd570bb264a37b73c35990, req_793f2f80d2915efa9132baa76b4fb659, req_db5f379b58755e6b8a7ba3e22f315826, req_f733dfb689045f05a53fcc41164e258e, req_06acdd527d915840823…
    Variable(id='status', name='Этап поручения', kind='enum', initial='Draft', requirement_ids=('req_91faa8ff7d5153d4b36fa5764a2a9804', 'req_48e457bf3dbd570bb264a37b73c35990', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_db5f379b58755e6b8a7ba3e22f315826', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_bf2da64ede4c56a2b9ce8dfb7110b8e8', 'req_9e63696a936b5f52a85f4221aa19c03a', 'req_979d1f8e4bc851b18f789209c88ca98b', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_9120945853e5590e8e776b1c1400a279', 'req_d95075df515d53209c12aefda8319544'), values=('Draft', 'Review', 'Approved', 'Paid', 'Cancelled')),
    # approved_a «Согласие А» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_793f2f80d2915efa9132baa76b4fb659, req_db5f379b58755e6b8a7ba3e22f315826, req_f733dfb689045f05a53fcc41164e258e, req_06acdd527d9158408233550bd32d8985, req_9e63696a936b5f52a85…
    Variable(id='approved_a', name='Согласие А', kind='boolean', initial=False, requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_db5f379b58755e6b8a7ba3e22f315826', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_9e63696a936b5f52a85f4221aa19c03a', 'req_43ee6409a1065372a3dbf1b686ed9caa', 'req_cee412ddc59a54e5aeb473ceff07d5af', 'req_d95075df515d53209c12aefda8319544')),
    # approved_b «Согласие Б» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_793f2f80d2915efa9132baa76b4fb659, req_db5f379b58755e6b8a7ba3e22f315826, req_f733dfb689045f05a53fcc41164e258e, req_06acdd527d9158408233550bd32d8985, req_9e63696a936b5f52a85…
    Variable(id='approved_b', name='Согласие Б', kind='boolean', initial=False, requirement_ids=('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_db5f379b58755e6b8a7ba3e22f315826', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_9e63696a936b5f52a85f4221aa19c03a', 'req_43ee6409a1065372a3dbf1b686ed9caa', 'req_c2e121b42fdd5aa38eff1086935be325', 'req_d95075df515d53209c12aefda8319544')),
    # cancelled «Поручение отменено» — req_bf2da64ede4c56a2b9ce8dfb7110b8e8, req_979d1f8e4bc851b18f789209c88ca98b, req_3fe7ae86fd8f554686b1bc436718900c, req_67ebe9432bfa533d819b177bdb7fb39e, req_d95075df515d53209c12aefda8319544
    Variable(id='cancelled', name='Поручение отменено', kind='boolean', initial=False, requirement_ids=('req_bf2da64ede4c56a2b9ce8dfb7110b8e8', 'req_979d1f8e4bc851b18f789209c88ca98b', 'req_3fe7ae86fd8f554686b1bc436718900c', 'req_67ebe9432bfa533d819b177bdb7fb39e', 'req_d95075df515d53209c12aefda8319544')),
    # executed «Поручение исполнено» — req_bf2da64ede4c56a2b9ce8dfb7110b8e8, req_979d1f8e4bc851b18f789209c88ca98b, req_43ee6409a1065372a3dbf1b686ed9caa, req_3fe7ae86fd8f554686b1bc436718900c, req_a6f0a511318e52ec9af24859ba5165e4, req_53587e990088…
    Variable(id='executed', name='Поручение исполнено', kind='boolean', initial=False, requirement_ids=('req_bf2da64ede4c56a2b9ce8dfb7110b8e8', 'req_979d1f8e4bc851b18f789209c88ca98b', 'req_43ee6409a1065372a3dbf1b686ed9caa', 'req_3fe7ae86fd8f554686b1bc436718900c', 'req_a6f0a511318e52ec9af24859ba5165e4', 'req_53587e990088571daef21a92363096b6', 'req_d95075df515d53209c12aefda8319544')),
)

INITIAL_STATE = {variable.id: variable.initial for variable in VARIABLES}
