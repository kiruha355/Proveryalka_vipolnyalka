"""Типы и конечные области значений переменных; проверка состояния модели."""
from dataclasses import dataclass
from typing import Optional


class InvalidState(ValueError):
    """Состояние не соответствует переменным или областям значений модели."""

    def __init__(self, variable, reason):
        super().__init__(f"{variable}: {reason}")
        self.variable = variable
        self.reason = reason


@dataclass(frozen=True)
class Variable:
    id: str
    name: str
    kind: str
    initial: object
    requirement_ids: tuple
    minimum: Optional[int] = None
    maximum: Optional[int] = None
    values: tuple = ()

    def contains(self, value):
        # bool не считается целым: True и 1 различаются, как в модели.
        if self.kind == "boolean":
            return type(value) is bool
        if self.kind == "integer":
            return type(value) is int and self.minimum <= value <= self.maximum
        return type(value) is str and value in self.values


def validate_state(variables, state):
    """Возвращает копию состояния или поднимает InvalidState."""
    if not isinstance(state, dict):
        raise InvalidState("*", "состояние должно быть объектом")
    known = {variable.id for variable in variables}
    for name in state:
        if name not in known:
            raise InvalidState(str(name), "переменной нет в модели")
    for variable in variables:
        if variable.id not in state:
            raise InvalidState(variable.id, "значение отсутствует")
        if not variable.contains(state[variable.id]):
            raise InvalidState(variable.id, f"значение {state[variable.id]!r} вне области {variable.kind}")
    return dict(state)
