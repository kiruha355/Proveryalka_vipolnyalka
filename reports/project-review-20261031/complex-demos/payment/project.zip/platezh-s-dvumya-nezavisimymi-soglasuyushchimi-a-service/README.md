# Платёж с двумя независимыми согласующими А и Б

Сервис сгенерирован `proveryalka-codegen 1.0.0` из согласованной версии модели. Изменения правил вносятся новой версией модели и повторной генерацией.

| Поле | Значение |
|---|---|
| version_id | `v_c5121f0e8fea4432aad69c10fff47607` |
| spec_hash | `3c63553df8f7f5b8c7f0c9798e4e3d4bbb4c045f0f33850141ed0be9e0458f42` |
| Цель | Python >=3.11, fastapi==0.162.0, pytest==8.3.5 |
| Проверка TLC | holds |

## Запуск

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
pytest
uvicorn app.api:app --port 8001
```

## API

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/model` | Переменные, области, переходы, ссылки на требования, version_id, spec_hash |
| GET | `/state` | Текущее состояние, номер ревизии, доступные переходы |
| POST | `/events` | `{"transition": id, "expected_revision"?: n}`: применить событие; 404 неизвестный переход, 409 условие ложно, выход за область или конфликт ревизии |
| POST | `/evaluate` | `{"state": {...}, "transition": id}`: вычислить переход без изменения состояния сервиса; 422 при недопустимом состоянии |
| POST | `/reset` | Вернуть начальное состояние |

## Переходы и требования

| Переход | Название | Требования | Присваивает | Код |
|---|---|---|---|---|
| `submit_for_review` | Подать на согласование | req\_48e457bf3dbd570bb264a37b73c35990, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | status | `app/rules.py:21` |
| `approve_a` | А даёт согласие | req\_d94ac30dc50c5cfeb67c9c2dddde3f83, req\_793f2f80d2915efa9132baa76b4fb659, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | approved_a | `app/rules.py:33` |
| `approve_b` | Б даёт согласие | req\_d94ac30dc50c5cfeb67c9c2dddde3f83, req\_793f2f80d2915efa9132baa76b4fb659, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | approved_b | `app/rules.py:45` |
| `complete_review` | Завершить согласование | req\_db5f379b58755e6b8a7ba3e22f315826, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | status | `app/rules.py:57` |
| `revoke_a` | А отзывает согласие | req\_d94ac30dc50c5cfeb67c9c2dddde3f83, req\_f733dfb689045f05a53fcc41164e258e, req\_06acdd527d9158408233550bd32d8985, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | approved_a, status | `app/rules.py:69` |
| `revoke_b` | Б отзывает согласие | req\_d94ac30dc50c5cfeb67c9c2dddde3f83, req\_f733dfb689045f05a53fcc41164e258e, req\_06acdd527d9158408233550bd32d8985, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | approved_b, status | `app/rules.py:82` |
| `pay` | Оплатить | req\_bf2da64ede4c56a2b9ce8dfb7110b8e8, req\_9e63696a936b5f52a85f4221aa19c03a, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | status, executed | `app/rules.py:95` |
| `cancel` | Отменить | req\_979d1f8e4bc851b18f789209c88ca98b, req\_85e0cfb054105e959c4b9775aafa50b7, req\_d95075df515d53209c12aefda8319544 | cancelled, status | `app/rules.py:108` |

## Требования

- **req\_d94ac30dc50c5cfeb67c9c2dddde3f83** — У платежа два независимых согласующих: А и Б.
- **req\_91faa8ff7d5153d4b36fa5764a2a9804** — Поручение имеет этап Draft, Review, Approved, Paid либо Cancelled.
- **req\_48e457bf3dbd570bb264a37b73c35990** — Действие «Подать на согласование» переводит поручение из Draft в Review.
- **req\_793f2f80d2915efa9132baa76b4fb659** — В Review каждый согласующий может отдельно поставить свою отметку согласия, если она ещё не стоит.
- **req\_db5f379b58755e6b8a7ba3e22f315826** — Отдельное действие «Завершить согласование» переводит поручение из Review в Approved только при наличии обеих отметок.
- **req\_f733dfb689045f05a53fcc41164e258e** — Каждый согласующий может отозвать свою отметку в Review или Approved.
- **req\_06acdd527d9158408233550bd32d8985** — Отзыв согласия любым из двух согласующих в Review или Approved одновременно снимает только его собственную отметку и устанавливает status=Review; остальные отметки и флаги сохраняются.
- **req\_bf2da64ede4c56a2b9ce8dfb7110b8e8** — Действие «Оплатить» разрешено только в Approved при отсутствии отмены; оно устанавливает этап Paid и executed=true.
- **req\_9e63696a936b5f52a85f4221aa19c03a** — Условие оплаты не перепроверяет отдельные отметки согласующих и доверяет этапу Approved.
- **req\_979d1f8e4bc851b18f789209c88ca98b** — Действие «Отменить» доступно в Draft, Review или Approved, если исполнение ещё не произошло; оно устанавливает cancelled=true и этап Cancelled.
- **req\_85e0cfb054105e959c4b9775aafa50b7** — Из Paid и Cancelled действий нет.
- **req\_43ee6409a1065372a3dbf1b686ed9caa** — После исполнения должны оставаться оба согласия.
- **req\_3fe7ae86fd8f554686b1bc436718900c** — Отменённый платёж не может быть исполнен.
- **req\_a6f0a511318e52ec9af24859ba5165e4** — Оплата должна быть достижима.
- **req\_9120945853e5590e8e776b1c1400a279** — Изначально status=Draft.
- **req\_cee412ddc59a54e5aeb473ceff07d5af** — Изначально approved\_a=false.
- **req\_c2e121b42fdd5aa38eff1086935be325** — Изначально approved\_b=false.
- **req\_67ebe9432bfa533d819b177bdb7fb39e** — Изначально cancelled=false.
- **req\_53587e990088571daef21a92363096b6** — Изначально executed=false.
- **req\_d95075df515d53209c12aefda8319544** — Неизменяемые переменные при каждом действии сохраняют прежние значения.

## Проверка модели (TLC)

TLC подтвердил все свойства модели для этой версии (в пределах лимитов проверки).

| Свойство | Вид | Статус | Проверка |
|---|---|---|---|
| `consents_after_execution` | invariant | PROPERTY_HOLDS | chk_45e60e439feb466381276192b402f277 |
| `cancelled_not_executed` | forbidden_state | PROPERTY_HOLDS | chk_45e60e439feb466381276192b402f277 |
| `payment_reachable` | reachable | PROPERTY_HOLDS | chk_45e60e439feb466381276192b402f277 |

## Что проверяют тесты

- `tests/test_transitions.py` и `tests/data/conformance.json`: 600 исходов переходов для 11 достижимых состояний (полный перебор) и 64 граничных состояний областей.
- `tests/test_domain.py`: типы и конечные области, 12 недопустимых состояний.
- `tests/test_api.py`: HTTP API на последовательности событий и отказах.
- `tests/test_traces.py`: повтор трасс TLC через код, трасс: 1.
- `tests/test_provenance.py`: spec_hash модели, состав переходов, переменных и ссылок на требования.

Тесты сравнивают код с семантикой модели на перечисленных состояниях. Они не доказывают соответствие во всех состояниях и не заменяют проверку свойств: статусы свойств получены TLC в пределах его лимитов.

## Файлы

- `README.md` — Описание, запуск, связь переходов с требованиями, результаты TLC.
- `GENERATION.json` — Происхождение: генератор, version_id, spec_hash, проверка TLC, SHA-256 файлов.
- `requirements.txt` — Зафиксированные версии всех зависимостей (Python ≥3.11).
- `pytest.ini` — Настройка pytest: каталог тестов и путь импорта.
- `model/behavioral_model.json` — Согласованная модель BehavioralModel 1.0 этой версии; её канонический SHA-256 равен spec_hash.
- `app/__init__.py` — Пакет сервиса.
- `app/spec.py` — Данные модели: требования, переменные с областями значений, начальное состояние, version_id и spec_hash.
- `app/domain.py` — Проверка типов и конечных областей значений состояния.
- `app/rules.py` — Условия и одновременные присваивания переходов (submit_for_review, approve_a, approve_b, complete_review, revoke_a, revoke_b, pay, cancel); у каждого перехода указаны требования.
- `app/engine.py` — Применение события: проверка состояния, условие, одновременное присваивание, проверка областей.
- `app/api.py` — FastAPI: GET /model, GET /state, POST /events, POST /evaluate, POST /reset.
- `tests/data/conformance.json` — Ожидаемые исходы переходов, недопустимые состояния и трассы TLC; вычислены по семантике модели при генерации.
- `tests/test_transitions.py` — Тесты переходов: применение, неизменные переменные, одновременность, ложное условие, выход за область, таблица исходов.
- `tests/test_domain.py` — Тесты типов и конечных областей значений.
- `tests/test_api.py` — Тесты HTTP API: последовательность событий, отказы 404/409/422, сброс.
- `tests/test_provenance.py` — Связь кода с моделью: spec_hash, состав переходов и переменных, ссылки на требования.
- `tests/test_traces.py` — Повтор трасс TLC этой версии через сгенерированный код; статус свойства определяет TLC.
