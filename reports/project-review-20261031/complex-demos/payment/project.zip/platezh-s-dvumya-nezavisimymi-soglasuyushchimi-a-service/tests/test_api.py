"""HTTP API: модель, состояние, применение событий и отказы."""
from fastapi.testclient import TestClient

from app.api import create_app
from app.spec import SPEC_HASH, VERSION_ID


INITIAL = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
INITIAL_ENABLED = ('submit_for_review', 'cancel')
TRANSITIONS = {'submit_for_review': ('req_48e457bf3dbd570bb264a37b73c35990', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'approve_a': ('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'approve_b': ('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_793f2f80d2915efa9132baa76b4fb659', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'complete_review': ('req_db5f379b58755e6b8a7ba3e22f315826', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'revoke_a': ('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'revoke_b': ('req_d94ac30dc50c5cfeb67c9c2dddde3f83', 'req_f733dfb689045f05a53fcc41164e258e', 'req_06acdd527d9158408233550bd32d8985', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'pay': ('req_bf2da64ede4c56a2b9ce8dfb7110b8e8', 'req_9e63696a936b5f52a85f4221aa19c03a', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544'), 'cancel': ('req_979d1f8e4bc851b18f789209c88ca98b', 'req_85e0cfb054105e959c4b9775aafa50b7', 'req_d95075df515d53209c12aefda8319544')}
PATH = (
    ('submit_for_review', {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}),
    ('approve_a', {'status': 'Review', 'approved_a': True, 'approved_b': False, 'cancelled': False, 'executed': False}),
    ('approve_b', {'status': 'Review', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}),
    ('complete_review', {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}),
    ('pay', {'status': 'Paid', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': True}),
)


def client():
    return TestClient(create_app())


def test_model_endpoint_links_version_and_requirements():
    body = client().get("/model").json()
    assert body["version_id"] == VERSION_ID
    assert body["spec_hash"] == SPEC_HASH
    assert {item["id"]: tuple(item["requirement_ids"]) for item in body["transitions"]} == TRANSITIONS


def test_initial_state():
    assert client().get("/state").json() == {"state": INITIAL, "revision": 0, "enabled": list(INITIAL_ENABLED)}


def test_event_sequence_over_http():
    api = client()
    for revision, (transition_id, expected) in enumerate(PATH, start=1):
        response = api.post("/events", json={"transition": transition_id, "expected_revision": revision - 1})
        assert response.status_code == 200, response.text
        assert response.json()["state"] == expected
        assert response.json()["revision"] == revision
    assert api.get("/state").json()["state"] == PATH[-1][1]


def test_reset_returns_initial_state():
    api = client()
    api.post("/events", json={"transition": PATH[0][0]})
    body = api.post("/reset").json()
    assert body["state"] == INITIAL


def test_disabled_event_is_rejected_and_state_kept():
    api = client()
    response = api.post("/events", json={"transition": 'approve_a'})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "TRANSITION_NOT_ENABLED"
    assert api.get("/state").json() == {"state": INITIAL, "revision": 0, "enabled": list(INITIAL_ENABLED)}


def test_unknown_transition_returns_404():
    response = client().post("/events", json={"transition": "__unknown__"})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "UNKNOWN_TRANSITION"


def test_revision_conflict_returns_409():
    response = client().post("/events", json={"transition": 'submit_for_review', "expected_revision": 99})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "REVISION_CONFLICT"


def test_request_body_is_validated():
    assert client().post("/events", json={"transition": 1}).status_code == 422
    assert client().post("/events", json={"transition": "x", "extra": True}).status_code == 422


def test_evaluate_rejects_invalid_state():
    response = client().post("/evaluate", json={"state": {}, "transition": "__unknown__"})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "INVALID_STATE"
