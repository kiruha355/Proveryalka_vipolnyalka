"""Проверка типов и конечных областей значений состояния."""
import json
from pathlib import Path

import pytest

from app import engine
from app.domain import InvalidState


TABLE = json.loads((Path(__file__).parent / "data" / "conformance.json").read_text(encoding="utf-8"))
CASES = TABLE["invalid_states"]


def test_initial_state_matches_model():
    assert engine.initial_state() == TABLE["initial_state"]
    assert engine.check_state(engine.initial_state()) == TABLE["initial_state"]


@pytest.mark.parametrize("case", CASES, ids=[case["id"] for case in CASES])
def test_invalid_state_is_rejected(case):
    with pytest.raises(InvalidState) as error:
        engine.check_state(case["state"])
    assert error.value.variable == case["variable"]


def test_state_must_be_an_object():
    with pytest.raises(InvalidState):
        engine.check_state([])
