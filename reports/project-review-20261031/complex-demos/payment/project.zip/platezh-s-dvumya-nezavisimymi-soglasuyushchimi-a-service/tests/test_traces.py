"""Повтор трасс TLC этой версии модели через сгенерированный код.

Статус свойства определяет TLC в пределах своих лимитов, а не эти тесты. Трасса нарушения
воспроизводится как поведение согласованной модели: генератор модель не исправляет.
"""
import json
from pathlib import Path

import pytest

from app import engine


TRACES = json.loads((Path(__file__).parent / "data" / "conformance.json").read_text(encoding="utf-8"))["traces"]


@pytest.mark.parametrize("trace", TRACES, ids=[trace["property_id"] for trace in TRACES])
def test_tlc_trace_is_reproduced(trace):
    state = engine.initial_state()
    assert state == trace["steps"][0]["state"]
    for step in trace["steps"][1:]:
        state = engine.apply(state, step["transition_id"])
        assert state == step["state"]
    if trace["kind"] == "deadlock_free" and trace["status"] == "PROPERTY_VIOLATED":
        assert engine.enabled_transitions(state) == []
