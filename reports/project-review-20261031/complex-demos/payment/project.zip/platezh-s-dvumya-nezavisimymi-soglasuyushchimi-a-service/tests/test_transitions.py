"""Тесты переходов: сгенерированные правила против семантики согласованной модели.

Ожидаемые состояния вычислены генератором по BehavioralModel 1.0 (proveryalka.behavior.step)
для этой версии. Тесты проверяют перечисленные состояния и не доказывают соответствие
во всех состояниях."""
import json
from pathlib import Path

import pytest

from app import engine


TABLE = json.loads((Path(__file__).parent / "data" / "conformance.json").read_text(encoding="utf-8"))
ROWS = TABLE["rows"]


# submit_for_review «Подать на согласование» — req_48e457bf3dbd570bb264a37b73c35990, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние — начальное
def test_submit_for_review_applies_effects_and_keeps_other_variables():
    before = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'submit_for_review')
    assert after == {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    kept = ('approved_a', 'approved_b', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}


def test_submit_for_review_rejected_when_guard_is_false():
    state = {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'submit_for_review')
    assert engine.check_state(state) == state


# approve_a «А даёт согласие» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_793f2f80d2915efa9132baa76b4fb659, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review
def test_approve_a_applies_effects_and_keeps_other_variables():
    before = {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'approve_a')
    assert after == {'status': 'Review', 'approved_a': True, 'approved_b': False, 'cancelled': False, 'executed': False}
    kept = ('status', 'approved_b', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}


def test_approve_a_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'approve_a')
    assert engine.check_state(state) == state


# approve_b «Б даёт согласие» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_793f2f80d2915efa9132baa76b4fb659, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review
def test_approve_b_applies_effects_and_keeps_other_variables():
    before = {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'approve_b')
    assert after == {'status': 'Review', 'approved_a': False, 'approved_b': True, 'cancelled': False, 'executed': False}
    kept = ('status', 'approved_a', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Review', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}


def test_approve_b_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'approve_b')
    assert engine.check_state(state) == state


# complete_review «Завершить согласование» — req_db5f379b58755e6b8a7ba3e22f315826, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review → approve_a → approve_b
def test_complete_review_applies_effects_and_keeps_other_variables():
    before = {'status': 'Review', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'complete_review')
    assert after == {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}
    kept = ('approved_a', 'approved_b', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Review', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}


def test_complete_review_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'complete_review')
    assert engine.check_state(state) == state


# revoke_a «А отзывает согласие» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_f733dfb689045f05a53fcc41164e258e, req_06acdd527d9158408233550bd32d8985, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review → approve_a → approve_b → complete_review
def test_revoke_a_applies_effects_and_keeps_other_variables():
    before = {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'revoke_a')
    assert after == {'status': 'Review', 'approved_a': False, 'approved_b': True, 'cancelled': False, 'executed': False}
    kept = ('approved_b', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}


def test_revoke_a_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'revoke_a')
    assert engine.check_state(state) == state


# revoke_b «Б отзывает согласие» — req_d94ac30dc50c5cfeb67c9c2dddde3f83, req_f733dfb689045f05a53fcc41164e258e, req_06acdd527d9158408233550bd32d8985, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review → approve_a → approve_b → complete_review
def test_revoke_b_applies_effects_and_keeps_other_variables():
    before = {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'revoke_b')
    assert after == {'status': 'Review', 'approved_a': True, 'approved_b': False, 'cancelled': False, 'executed': False}
    kept = ('approved_a', 'cancelled', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}


def test_revoke_b_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'revoke_b')
    assert engine.check_state(state) == state


# pay «Оплатить» — req_bf2da64ede4c56a2b9ce8dfb7110b8e8, req_9e63696a936b5f52a85f4221aa19c03a, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние достигается из начального: submit_for_review → approve_a → approve_b → complete_review
def test_pay_applies_effects_and_keeps_other_variables():
    before = {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'pay')
    assert after == {'status': 'Paid', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': True}
    kept = ('approved_a', 'approved_b', 'cancelled')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Approved', 'approved_a': True, 'approved_b': True, 'cancelled': False, 'executed': False}


def test_pay_rejected_when_guard_is_false():
    state = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'pay')
    assert engine.check_state(state) == state


# cancel «Отменить» — req_979d1f8e4bc851b18f789209c88ca98b, req_85e0cfb054105e959c4b9775aafa50b7, req_d95075df515d53209c12aefda8319544
# Исходное состояние — начальное
def test_cancel_applies_effects_and_keeps_other_variables():
    before = {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}
    after = engine.apply(before, 'cancel')
    assert after == {'status': 'Cancelled', 'approved_a': False, 'approved_b': False, 'cancelled': True, 'executed': False}
    kept = ('approved_a', 'approved_b', 'executed')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'status': 'Draft', 'approved_a': False, 'approved_b': False, 'cancelled': False, 'executed': False}


def test_cancel_rejected_when_guard_is_false():
    state = {'status': 'Cancelled', 'approved_a': False, 'approved_b': False, 'cancelled': True, 'executed': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'cancel')
    assert engine.check_state(state) == state


@pytest.mark.parametrize("row", ROWS, ids=[row["id"] for row in ROWS])
def test_conformance_table(row):
    if row["outcome"] == "applied":
        assert engine.apply(row["state"], row["transition"]) == row["next"]
        return
    expected = engine.TransitionNotEnabled if row["outcome"] == "not_enabled" else engine.EffectOutOfDomain
    with pytest.raises(expected):
        engine.apply(row["state"], row["transition"])


def test_unknown_transition_is_rejected():
    with pytest.raises(engine.UnknownTransition):
        engine.apply(engine.initial_state(), '__unknown__')
