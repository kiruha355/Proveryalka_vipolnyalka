"""Связь кода с согласованной моделью: spec_hash, переходы, переменные и ссылки на требования."""
import hashlib
import json
from pathlib import Path

from app.rules import TRANSITIONS
from app.spec import REQUIREMENTS, SPEC_HASH, VARIABLES


MODEL = json.loads((Path(__file__).resolve().parents[1] / "model" / "behavioral_model.json").read_text(encoding="utf-8"))


def test_model_file_matches_spec_hash():
    canonical = json.dumps(MODEL, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
    assert hashlib.sha256(canonical.encode("utf-8")).hexdigest() == SPEC_HASH


def test_rules_follow_model_transitions():
    assert list(TRANSITIONS) == [item["id"] for item in MODEL["transitions"]]
    for item in MODEL["transitions"]:
        rule = TRANSITIONS[item["id"]]
        assert rule.requirement_ids == tuple(item["requirement_ids"])
        assert rule.assigns == tuple(effect["variable"] for effect in item["effects"])


def test_variables_follow_model():
    expected = [(item["id"], item["domain"]["kind"], item["initial_value"]) for item in MODEL["variables"]]
    assert [(variable.id, variable.kind, variable.initial) for variable in VARIABLES] == expected


def test_requirement_references_exist():
    assert set(REQUIREMENTS) == {item["id"] for item in MODEL["requirements"]}
    for rule in TRANSITIONS.values():
        assert set(rule.requirement_ids) <= set(REQUIREMENTS)
    for variable in VARIABLES:
        assert set(variable.requirement_ids) <= set(REQUIREMENTS)
