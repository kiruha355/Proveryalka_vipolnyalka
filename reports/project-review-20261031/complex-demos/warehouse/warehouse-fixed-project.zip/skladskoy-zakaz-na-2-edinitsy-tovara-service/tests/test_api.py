"""HTTP API: модель, состояние, применение событий и отказы."""
from fastapi.testclient import TestClient

from app.api import create_app
from app.spec import SPEC_HASH, VERSION_ID


INITIAL = {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}
INITIAL_ENABLED = ('Reserve',)
TRANSITIONS = {'Reserve': ('req_01189db190aa5159bdcdc73494608354', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_48259ccb945e54d8989e4f57a0444772', 'req_7c99c5073dc851a4ae034766bc5a5a0e'), 'Pay': ('req_cedc5f58642c5065b13d45623abd271a', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_48259ccb945e54d8989e4f57a0444772', 'req_7c99c5073dc851a4ae034766bc5a5a0e'), 'Ship': ('req_e15ae391f9305927803d48f74e33b06b', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_48259ccb945e54d8989e4f57a0444772', 'req_7c99c5073dc851a4ae034766bc5a5a0e'), 'Cancel': ('req_b7d1273bbb4a5e5fab60f9aec513dd0d', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_48259ccb945e54d8989e4f57a0444772', 'req_7c99c5073dc851a4ae034766bc5a5a0e')}
PATH = (
    ('Reserve', {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}),
    ('Pay', {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': True}),
    ('Ship', {'available': 1, 'reserved': 0, 'shipped': 2, 'status': 'Shipped', 'paid': True}),
)


def client():
    return TestClient(create_app())


def test_model_endpoint_links_version_and_requirements():
    body = client().get("/model").json()
    assert body["version_id"] == VERSION_ID
    assert body["spec_hash"] == SPEC_HASH
    assert {item["id"]: tuple(item["requirement_ids"]) for item in body["transitions"]} == TRANSITIONS


def test_initial_state():
    assert client().get("/state").json() == {"state": INITIAL, "revision": 0, "enabled": list(INITIAL_ENABLED)}


def test_event_sequence_over_http():
    api = client()
    for revision, (transition_id, expected) in enumerate(PATH, start=1):
        response = api.post("/events", json={"transition": transition_id, "expected_revision": revision - 1})
        assert response.status_code == 200, response.text
        assert response.json()["state"] == expected
        assert response.json()["revision"] == revision
    assert api.get("/state").json()["state"] == PATH[-1][1]


def test_reset_returns_initial_state():
    api = client()
    api.post("/events", json={"transition": PATH[0][0]})
    body = api.post("/reset").json()
    assert body["state"] == INITIAL


def test_disabled_event_is_rejected_and_state_kept():
    api = client()
    response = api.post("/events", json={"transition": 'Pay'})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "TRANSITION_NOT_ENABLED"
    assert api.get("/state").json() == {"state": INITIAL, "revision": 0, "enabled": list(INITIAL_ENABLED)}


def test_unknown_transition_returns_404():
    response = client().post("/events", json={"transition": "__unknown__"})
    assert response.status_code == 404
    assert response.json()["error"]["code"] == "UNKNOWN_TRANSITION"


def test_revision_conflict_returns_409():
    response = client().post("/events", json={"transition": 'Reserve', "expected_revision": 99})
    assert response.status_code == 409
    assert response.json()["error"]["code"] == "REVISION_CONFLICT"


def test_request_body_is_validated():
    assert client().post("/events", json={"transition": 1}).status_code == 422
    assert client().post("/events", json={"transition": "x", "extra": True}).status_code == 422


def test_evaluate_rejects_invalid_state():
    response = client().post("/evaluate", json={"state": {}, "transition": "__unknown__"})
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "INVALID_STATE"
