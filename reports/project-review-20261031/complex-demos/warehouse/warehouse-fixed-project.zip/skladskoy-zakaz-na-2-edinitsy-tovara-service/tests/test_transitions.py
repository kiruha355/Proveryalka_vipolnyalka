"""Тесты переходов: сгенерированные правила против семантики согласованной модели.

Ожидаемые состояния вычислены генератором по BehavioralModel 1.0 (proveryalka.behavior.step)
для этой версии. Тесты проверяют перечисленные состояния и не доказывают соответствие
во всех состояниях."""
import json
from pathlib import Path

import pytest

from app import engine


TABLE = json.loads((Path(__file__).parent / "data" / "conformance.json").read_text(encoding="utf-8"))
ROWS = TABLE["rows"]


# Reserve «Резервирование товара» — req_01189db190aa5159bdcdc73494608354, req_588c5a93353c513eb5afb57508df4fb0, req_48259ccb945e54d8989e4f57a0444772, req_7c99c5073dc851a4ae034766bc5a5a0e
# Исходное состояние — начальное
def test_Reserve_applies_effects_and_keeps_other_variables():
    before = {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}
    after = engine.apply(before, 'Reserve')
    assert after == {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}
    kept = ('shipped', 'paid')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}


def test_Reserve_rejected_when_guard_is_false():
    state = {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'Reserve')
    assert engine.check_state(state) == state


# Pay «Оплата заказа» — req_cedc5f58642c5065b13d45623abd271a, req_588c5a93353c513eb5afb57508df4fb0, req_48259ccb945e54d8989e4f57a0444772, req_7c99c5073dc851a4ae034766bc5a5a0e
# Исходное состояние достигается из начального: Reserve
def test_Pay_applies_effects_and_keeps_other_variables():
    before = {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}
    after = engine.apply(before, 'Pay')
    assert after == {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': True}
    kept = ('available', 'reserved', 'shipped', 'status')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}


def test_Pay_rejected_when_guard_is_false():
    state = {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'Pay')
    assert engine.check_state(state) == state


# Ship «Отгрузка товара» — req_e15ae391f9305927803d48f74e33b06b, req_588c5a93353c513eb5afb57508df4fb0, req_48259ccb945e54d8989e4f57a0444772, req_7c99c5073dc851a4ae034766bc5a5a0e
# Исходное состояние достигается из начального: Reserve → Pay
def test_Ship_applies_effects_and_keeps_other_variables():
    before = {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': True}
    after = engine.apply(before, 'Ship')
    assert after == {'available': 1, 'reserved': 0, 'shipped': 2, 'status': 'Shipped', 'paid': True}
    kept = ('available', 'paid')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': True}


def test_Ship_rejected_when_guard_is_false():
    state = {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'Ship')
    assert engine.check_state(state) == state


# Cancel «Отмена заказа» — req_b7d1273bbb4a5e5fab60f9aec513dd0d, req_588c5a93353c513eb5afb57508df4fb0, req_48259ccb945e54d8989e4f57a0444772, req_7c99c5073dc851a4ae034766bc5a5a0e
# Исходное состояние достигается из начального: Reserve
def test_Cancel_applies_effects_and_keeps_other_variables():
    before = {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}
    after = engine.apply(before, 'Cancel')
    assert after == {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Cancelled', 'paid': False}
    kept = ('shipped', 'paid')
    assert {name: after[name] for name in kept} == {name: before[name] for name in kept}
    assert before == {'available': 1, 'reserved': 2, 'shipped': 0, 'status': 'Reserved', 'paid': False}


def test_Cancel_rejected_when_guard_is_false():
    state = {'available': 3, 'reserved': 0, 'shipped': 0, 'status': 'Draft', 'paid': False}
    with pytest.raises(engine.TransitionNotEnabled):
        engine.apply(state, 'Cancel')
    assert engine.check_state(state) == state


@pytest.mark.parametrize("row", ROWS, ids=[row["id"] for row in ROWS])
def test_conformance_table(row):
    if row["outcome"] == "applied":
        assert engine.apply(row["state"], row["transition"]) == row["next"]
        return
    expected = engine.TransitionNotEnabled if row["outcome"] == "not_enabled" else engine.EffectOutOfDomain
    with pytest.raises(expected):
        engine.apply(row["state"], row["transition"])


def test_unknown_transition_is_rejected():
    with pytest.raises(engine.UnknownTransition):
        engine.apply(engine.initial_state(), '__unknown__')
