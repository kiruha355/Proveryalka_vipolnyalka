# Складской заказ на 2 единицы товара

Сервис сгенерирован `proveryalka-codegen 1.0.0` из согласованной версии модели. Изменения правил вносятся новой версией модели и повторной генерацией.

| Поле | Значение |
|---|---|
| version_id | `v_2a9cb60dcb45449a81b0149d445dea91` |
| spec_hash | `a2021739f33d8b1933893d3f40096081cbbb249babd67a7d9eb769bb952efaaf` |
| Цель | Python >=3.11, fastapi==0.162.0, pytest==8.3.5 |
| Проверка TLC | holds |

## Запуск

```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
pytest
uvicorn app.api:app --port 8001
```

## API

| Метод | Путь | Назначение |
|---|---|---|
| GET | `/model` | Переменные, области, переходы, ссылки на требования, version_id, spec_hash |
| GET | `/state` | Текущее состояние, номер ревизии, доступные переходы |
| POST | `/events` | `{"transition": id, "expected_revision"?: n}`: применить событие; 404 неизвестный переход, 409 условие ложно, выход за область или конфликт ревизии |
| POST | `/evaluate` | `{"state": {...}, "transition": id}`: вычислить переход без изменения состояния сервиса; 422 при недопустимом состоянии |
| POST | `/reset` | Вернуть начальное состояние |

## Переходы и требования

| Переход | Название | Требования | Присваивает | Код |
|---|---|---|---|---|
| `Reserve` | Резервирование товара | req\_01189db190aa5159bdcdc73494608354, req\_588c5a93353c513eb5afb57508df4fb0, req\_48259ccb945e54d8989e4f57a0444772, req\_7c99c5073dc851a4ae034766bc5a5a0e | available, reserved, status | `app/rules.py:21` |
| `Pay` | Оплата заказа | req\_cedc5f58642c5065b13d45623abd271a, req\_588c5a93353c513eb5afb57508df4fb0, req\_48259ccb945e54d8989e4f57a0444772, req\_7c99c5073dc851a4ae034766bc5a5a0e | paid | `app/rules.py:35` |
| `Ship` | Отгрузка товара | req\_e15ae391f9305927803d48f74e33b06b, req\_588c5a93353c513eb5afb57508df4fb0, req\_48259ccb945e54d8989e4f57a0444772, req\_7c99c5073dc851a4ae034766bc5a5a0e | reserved, shipped, status | `app/rules.py:47` |
| `Cancel` | Отмена заказа | req\_b7d1273bbb4a5e5fab60f9aec513dd0d, req\_588c5a93353c513eb5afb57508df4fb0, req\_48259ccb945e54d8989e4f57a0444772, req\_7c99c5073dc851a4ae034766bc5a5a0e | available, reserved, status | `app/rules.py:61` |

## Требования

- **req\_03deace4698956baa1d158bae7144b21** — Складской заказ содержит 2 единицы товара.
- **req\_6f773e210e525ff9bf14dd6dfc53cae0** — На складе всего 3 единицы товара.
- **req\_80d0d74789ad59458d4d1af903bbac6a** — Нужна конечная модель.
- **req\_62082f2c4316547a92b7284402c07ef9** — available — целое число от 0 до 3.
- **req\_efd35998b8fb512280b43b68a3f3ccc5** — reserved — целое число от 0 до 2.
- **req\_82d4ebac821b548d97d7571e6032c1da** — shipped — целое число от 0 до 2.
- **req\_d5b51c5f67025ea083664a4cec1162f3** — status принимает значения Draft, Reserved, Cancelled или Shipped.
- **req\_2e3e4f8cab7350b8b5d5a198a6fb1261** — paid — логическая переменная.
- **req\_338a353901a053cca219f1d9ad1c623b** — Изначально status=Draft, available=3, reserved=0, shipped=0.
- **req\_01189db190aa5159bdcdc73494608354** — Reserve разрешён только из Draft при available&gt;=2. Одновременно available уменьшается на 2, reserved становится 2, status становится Reserved.
- **req\_cedc5f58642c5065b13d45623abd271a** — Pay разрешён только при status=Reserved и paid=false. Устанавливает paid=true.
- **req\_e15ae391f9305927803d48f74e33b06b** — Ship разрешён только при status=Reserved, paid=true и reserved=2. Одновременно reserved=0, shipped=2, status=Shipped.
- **req\_b7d1273bbb4a5e5fab60f9aec513dd0d** — Cancel разрешён только при status=Reserved. Одновременно available=available+reserved, reserved=0 и status=Cancelled. Сумма available+reserved вычисляется по значениям до перехода. paid и shipped сохраняются.
- **req\_588c5a93353c513eb5afb57508df4fb0** — Все неуказанные переменные сохраняются.
- **req\_48259ccb945e54d8989e4f57a0444772** — Из Cancelled и Shipped действий нет.
- **req\_53f0aacca8a655fda64bd98d97cf9689** — available+reserved+shipped всегда должно равняться 3.
- **req\_2ddcf9d9be615ddfa344b007ac1a694e** — Отменённый заказ не должен иметь отгруженный товар.
- **req\_f72c5632436250608131945ae1e69140** — Отгрузка возможна только после оплаты.
- **req\_7c99c5073dc851a4ae034766bc5a5a0e** — Критерии проверяются как свойства модели и не являются дополнительными guards.
- **req\_9b6c87c4a9e05c3885202d50fde7e21e** — Изначально paid=false: заказ ещё не оплачен.

## Проверка модели (TLC)

TLC подтвердил все свойства модели для этой версии (в пределах лимитов проверки).

| Свойство | Вид | Статус | Проверка |
|---|---|---|---|
| `stock_conservation` | invariant | PROPERTY_HOLDS | chk_6855eb4a0119493a9189ae1328c81799 |
| `cancelled_without_shipment` | invariant | PROPERTY_HOLDS | chk_6855eb4a0119493a9189ae1328c81799 |
| `shipment_requires_payment` | invariant | PROPERTY_HOLDS | chk_6855eb4a0119493a9189ae1328c81799 |

## Что проверяют тесты

- `tests/test_transitions.py` и `tests/data/conformance.json`: 280 исходов переходов для 6 достижимых состояний (полный перебор) и 64 граничных состояний областей.
- `tests/test_domain.py`: типы и конечные области, 18 недопустимых состояний.
- `tests/test_api.py`: HTTP API на последовательности событий и отказах.
- Трасс TLC в снимке проверки нет, файл повтора трасс не создан.
- `tests/test_provenance.py`: spec_hash модели, состав переходов, переменных и ссылок на требования.

Тесты сравнивают код с семантикой модели на перечисленных состояниях. Они не доказывают соответствие во всех состояниях и не заменяют проверку свойств: статусы свойств получены TLC в пределах его лимитов.

## Файлы

- `README.md` — Описание, запуск, связь переходов с требованиями, результаты TLC.
- `GENERATION.json` — Происхождение: генератор, version_id, spec_hash, проверка TLC, SHA-256 файлов.
- `requirements.txt` — Зафиксированные версии всех зависимостей (Python ≥3.11).
- `pytest.ini` — Настройка pytest: каталог тестов и путь импорта.
- `model/behavioral_model.json` — Согласованная модель BehavioralModel 1.0 этой версии; её канонический SHA-256 равен spec_hash.
- `app/__init__.py` — Пакет сервиса.
- `app/spec.py` — Данные модели: требования, переменные с областями значений, начальное состояние, version_id и spec_hash.
- `app/domain.py` — Проверка типов и конечных областей значений состояния.
- `app/rules.py` — Условия и одновременные присваивания переходов (Reserve, Pay, Ship, Cancel); у каждого перехода указаны требования.
- `app/engine.py` — Применение события: проверка состояния, условие, одновременное присваивание, проверка областей.
- `app/api.py` — FastAPI: GET /model, GET /state, POST /events, POST /evaluate, POST /reset.
- `tests/data/conformance.json` — Ожидаемые исходы переходов, недопустимые состояния и трассы TLC; вычислены по семантике модели при генерации.
- `tests/test_transitions.py` — Тесты переходов: применение, неизменные переменные, одновременность, ложное условие, выход за область, таблица исходов.
- `tests/test_domain.py` — Тесты типов и конечных областей значений.
- `tests/test_api.py` — Тесты HTTP API: последовательность событий, отказы 404/409/422, сброс.
- `tests/test_provenance.py` — Связь кода с моделью: spec_hash, состав переходов и переменных, ссылки на требования.
