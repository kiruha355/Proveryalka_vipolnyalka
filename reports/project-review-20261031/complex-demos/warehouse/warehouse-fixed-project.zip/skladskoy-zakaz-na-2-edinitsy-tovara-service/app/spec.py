"""Данные согласованной модели: требования, переменные, области значений, начальное состояние."""
from .domain import Variable


# Модель: Складской заказ на 2 единицы товара
MODEL_NAME = 'Складской заказ на 2 единицы товара'
VERSION_ID = 'v_2a9cb60dcb45449a81b0149d445dea91'
SPEC_HASH = 'a2021739f33d8b1933893d3f40096081cbbb249babd67a7d9eb769bb952efaaf'
GENERATOR = 'proveryalka-codegen 1.0.0'

REQUIREMENTS = {
    'req_03deace4698956baa1d158bae7144b21': 'Складской заказ содержит 2 единицы товара.',
    'req_6f773e210e525ff9bf14dd6dfc53cae0': 'На складе всего 3 единицы товара.',
    'req_80d0d74789ad59458d4d1af903bbac6a': 'Нужна конечная модель.',
    'req_62082f2c4316547a92b7284402c07ef9': 'available — целое число от 0 до 3.',
    'req_efd35998b8fb512280b43b68a3f3ccc5': 'reserved — целое число от 0 до 2.',
    'req_82d4ebac821b548d97d7571e6032c1da': 'shipped — целое число от 0 до 2.',
    'req_d5b51c5f67025ea083664a4cec1162f3': 'status принимает значения Draft, Reserved, Cancelled или Shipped.',
    'req_2e3e4f8cab7350b8b5d5a198a6fb1261': 'paid — логическая переменная.',
    'req_338a353901a053cca219f1d9ad1c623b': 'Изначально status=Draft, available=3, reserved=0, shipped=0.',
    'req_01189db190aa5159bdcdc73494608354': 'Reserve разрешён только из Draft при available>=2. Одновременно available уменьшается на 2, reserved становится 2, status становится Reserved.',
    'req_cedc5f58642c5065b13d45623abd271a': 'Pay разрешён только при status=Reserved и paid=false. Устанавливает paid=true.',
    'req_e15ae391f9305927803d48f74e33b06b': 'Ship разрешён только при status=Reserved, paid=true и reserved=2. Одновременно reserved=0, shipped=2, status=Shipped.',
    'req_b7d1273bbb4a5e5fab60f9aec513dd0d': 'Cancel разрешён только при status=Reserved. Одновременно available=available+reserved, reserved=0 и status=Cancelled. Сумма available+reserved вычисляется по значениям до перехода. paid и shipped сохраняются.',
    'req_588c5a93353c513eb5afb57508df4fb0': 'Все неуказанные переменные сохраняются.',
    'req_48259ccb945e54d8989e4f57a0444772': 'Из Cancelled и Shipped действий нет.',
    'req_53f0aacca8a655fda64bd98d97cf9689': 'available+reserved+shipped всегда должно равняться 3.',
    'req_2ddcf9d9be615ddfa344b007ac1a694e': 'Отменённый заказ не должен иметь отгруженный товар.',
    'req_f72c5632436250608131945ae1e69140': 'Отгрузка возможна только после оплаты.',
    'req_7c99c5073dc851a4ae034766bc5a5a0e': 'Критерии проверяются как свойства модели и не являются дополнительными guards.',
    'req_9b6c87c4a9e05c3885202d50fde7e21e': 'Изначально paid=false: заказ ещё не оплачен.',
}

VARIABLES = (
    # available «Доступное количество товара» — req_6f773e210e525ff9bf14dd6dfc53cae0, req_62082f2c4316547a92b7284402c07ef9, req_338a353901a053cca219f1d9ad1c623b, req_01189db190aa5159bdcdc73494608354, req_b7d1273bbb4a5e5fab60f9aec513dd0d, req_588…
    Variable(id='available', name='Доступное количество товара', kind='integer', initial=3, requirement_ids=('req_6f773e210e525ff9bf14dd6dfc53cae0', 'req_62082f2c4316547a92b7284402c07ef9', 'req_338a353901a053cca219f1d9ad1c623b', 'req_01189db190aa5159bdcdc73494608354', 'req_b7d1273bbb4a5e5fab60f9aec513dd0d', 'req_588c5a93353c513eb5afb57508df4fb0'), minimum=0, maximum=3),
    # reserved «Зарезервированное количество товара» — req_efd35998b8fb512280b43b68a3f3ccc5, req_338a353901a053cca219f1d9ad1c623b, req_01189db190aa5159bdcdc73494608354, req_e15ae391f9305927803d48f74e33b06b, req_b7d1273bbb4a5e5fab60f9aec513dd0d, …
    Variable(id='reserved', name='Зарезервированное количество товара', kind='integer', initial=0, requirement_ids=('req_efd35998b8fb512280b43b68a3f3ccc5', 'req_338a353901a053cca219f1d9ad1c623b', 'req_01189db190aa5159bdcdc73494608354', 'req_e15ae391f9305927803d48f74e33b06b', 'req_b7d1273bbb4a5e5fab60f9aec513dd0d', 'req_588c5a93353c513eb5afb57508df4fb0'), minimum=0, maximum=2),
    # shipped «Отгруженное количество товара» — req_82d4ebac821b548d97d7571e6032c1da, req_338a353901a053cca219f1d9ad1c623b, req_e15ae391f9305927803d48f74e33b06b, req_588c5a93353c513eb5afb57508df4fb0
    Variable(id='shipped', name='Отгруженное количество товара', kind='integer', initial=0, requirement_ids=('req_82d4ebac821b548d97d7571e6032c1da', 'req_338a353901a053cca219f1d9ad1c623b', 'req_e15ae391f9305927803d48f74e33b06b', 'req_588c5a93353c513eb5afb57508df4fb0'), minimum=0, maximum=2),
    # status «Статус заказа» — req_d5b51c5f67025ea083664a4cec1162f3, req_338a353901a053cca219f1d9ad1c623b, req_01189db190aa5159bdcdc73494608354, req_cedc5f58642c5065b13d45623abd271a, req_e15ae391f9305927803d48f74e33b06b, req_b7d1273bbb4a5e5fab60…
    Variable(id='status', name='Статус заказа', kind='enum', initial='Draft', requirement_ids=('req_d5b51c5f67025ea083664a4cec1162f3', 'req_338a353901a053cca219f1d9ad1c623b', 'req_01189db190aa5159bdcdc73494608354', 'req_cedc5f58642c5065b13d45623abd271a', 'req_e15ae391f9305927803d48f74e33b06b', 'req_b7d1273bbb4a5e5fab60f9aec513dd0d', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_48259ccb945e54d8989e4f57a0444772'), values=('Draft', 'Reserved', 'Cancelled', 'Shipped')),
    # paid «Заказ оплачен» — req_2e3e4f8cab7350b8b5d5a198a6fb1261, req_cedc5f58642c5065b13d45623abd271a, req_e15ae391f9305927803d48f74e33b06b, req_588c5a93353c513eb5afb57508df4fb0, req_9b6c87c4a9e05c3885202d50fde7e21e
    Variable(id='paid', name='Заказ оплачен', kind='boolean', initial=False, requirement_ids=('req_2e3e4f8cab7350b8b5d5a198a6fb1261', 'req_cedc5f58642c5065b13d45623abd271a', 'req_e15ae391f9305927803d48f74e33b06b', 'req_588c5a93353c513eb5afb57508df4fb0', 'req_9b6c87c4a9e05c3885202d50fde7e21e')),
)

INITIAL_STATE = {variable.id: variable.initial for variable in VARIABLES}
